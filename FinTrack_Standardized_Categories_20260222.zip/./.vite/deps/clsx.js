import {
  clsx,
  clsx_default
} from "./chunk-KDVGFZWC.js";
import "./chunk-DC5AMYBS.js";
export {
  clsx,
  clsx_default as default
};
//# sourceMappingURL=clsx.js.map
