import {
  require_react_dom
} from "./chunk-BC63SET5.js";
import "./chunk-TWJRYSII.js";
import "./chunk-DC5AMYBS.js";
export default require_react_dom();
//# sourceMappingURL=react-dom.js.map
